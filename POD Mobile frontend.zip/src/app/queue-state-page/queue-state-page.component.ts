import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-queue-state-page',
  templateUrl: './queue-state-page.component.html',
  styleUrls: ['./queue-state-page.component.css']
})
export class QueueStatePageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
