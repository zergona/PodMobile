import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sent-request',
  templateUrl: './sent-request.component.html',
  styleUrls: ['./sent-request.component.css']
})
export class SentRequestComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
