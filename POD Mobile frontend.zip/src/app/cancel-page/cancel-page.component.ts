import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-cancel-page',
  templateUrl: './cancel-page.component.html',
  styleUrls: ['./cancel-page.component.css']
})
export class CancelPageComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
